from .core import Metadata

__all__ = ['Metadata']
